create function date_part(text, abstime) returns double precision
    stable
    strict
    parallel safe
    cost 1
    language sql
as
$$select pg_catalog.date_part($1, cast($2 as timestamp with time zone))$$;

comment on function date_part(text, abstime) is 'extract field from abstime';

alter function date_part(text, abstime) owner to postgres;

